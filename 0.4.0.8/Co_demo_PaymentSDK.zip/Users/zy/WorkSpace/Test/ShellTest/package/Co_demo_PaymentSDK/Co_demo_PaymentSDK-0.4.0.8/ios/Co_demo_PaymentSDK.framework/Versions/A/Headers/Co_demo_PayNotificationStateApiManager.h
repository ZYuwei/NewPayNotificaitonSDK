//
//  Co_demo_PayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Co_demo_PayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "Co_demo_PayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^Co_demo_PayNotificationStateApiCompleteBlock) (Co_demo_PayNotificationHTTPResponse *response);

@interface Co_demo_PayNotificationStateApiManager : AFHTTPSessionManager
+ (Co_demo_PayNotificationStateApiManager *)co_demo_sharedManager;
//支付成功新增后台 通知接口
-(void)co_demo_checkiOSIAPPayOrderWithPayNotificationModel:(Co_demo_PayNotificationModel *)payNotificationModel  complete:(Co_demo_PayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
