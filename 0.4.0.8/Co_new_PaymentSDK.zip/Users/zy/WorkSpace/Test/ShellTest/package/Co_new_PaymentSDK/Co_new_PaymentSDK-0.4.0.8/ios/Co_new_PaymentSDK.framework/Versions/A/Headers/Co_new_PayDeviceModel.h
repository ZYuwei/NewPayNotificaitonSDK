//
//  Co_new_PayDeviceModel.h
//  FMDB
//
//  Created by qiaoming on 2018/12/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Co_new_PayDeviceModel : NSObject
+ (NSDictionary *)co_new_device;
@end

NS_ASSUME_NONNULL_END
