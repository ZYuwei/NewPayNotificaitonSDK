//
//  Co_new_PayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "Co_new_PayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface Co_new_PayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)co_new_saveToCacheWithProductId:(NSString *)product_id;
+(Co_new_PayNotificationModel*)co_new_unSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)co_new_delSerializedBean:(Co_new_PayNotificationModel*)bean;
+(NSArray <Co_new_PayNotificationModel *>*)co_new_getSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)co_new_retryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
