//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface Zy_TestDemo_NcsStTest : NSObject

+(void)zy_TestDemo_test;

+(void)zy_TestDemo_testOld;

@end
