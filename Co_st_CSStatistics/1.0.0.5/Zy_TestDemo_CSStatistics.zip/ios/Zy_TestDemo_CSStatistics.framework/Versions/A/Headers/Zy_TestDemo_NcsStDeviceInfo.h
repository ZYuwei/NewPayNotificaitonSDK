//
//  Zy_TestDemo_NcsStDeviceInfo.h
//  GLive
//
//  Created by Gordon Su on 17/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Zy_TestDemo_NcsStDeviceInfo : NSObject

+ (NSDictionary *)zy_TestDemo_device;

+ (NSDictionary *)zy_TestDemo_deviceForNetworkMonitor;

/**
 本机UDID (实际上为UUID, 存储在keychain来替代UDID)
 */
+ (NSString *)zy_TestDemo_UDIDString;

/**
 Apple广告 id
 */
+ (NSString *)zy_TestDemo_advertiseIDString;

/**
 当前国家码 (根据运营商获取)
 */
+ (NSString *)zy_TestDemo_getCurrentMoblileCountryCode;

/**
 当前地区名称
 */
+ (NSString *)zy_TestDemo_getDeviceCountryName;

/**
 当前本地语言
 */
+ (NSString *)zy_TestDemo_getDeviceLangName;

/**
 应用版本号
 */
+ (NSString *)zy_TestDemo_getAppVersion;

/**
 应用build 版本号
 */
+ (NSString *)zy_TestDemo_getAppBuildVersion;

/**
 本机系统版本
 */
+ (NSString *)zy_TestDemo_getiOSVersion;

/**
 本地CPU类型
 */
+ (NSString *)zy_TestDemo_getCPUType;


/**
 App ID
 */
+ (NSString *)zy_TestDemo_getAppID;


/**
 Bundle ID
 */
+ (NSString *)zy_TestDemo_getBundleId;


/**
 获取当前IP
 */
+ (NSString *)zy_TestDemo_getIPAddress;

/**
 获取当前DNS
 */
+ (NSArray *)zy_TestDemo_getDNSAddresses;

/**
 根据域名获取IP地址
 */
+ (NSString*)zy_TestDemo_getIPAddressByHostName:(NSString*)strHostName;

/**
 CSID
 */
+ (NSString *)zy_TestDemo_getCSID;

/**
 新用户ID (协议需求)
 */
+ (NSString *)zy_TestDemo_getCustomerNewId;


/**
 设备类型 (iPhone / iPad)
 */
+ (BOOL)zy_TestDemo_isIpad;

//*日志打印时间
//客户端日志的打印时间；格式如：2013-02-26 12:00:02；默认转成中国时区
//+ (NSString *)getTimeStamp;

//获取具体的机型 型号
+ (NSString *)zy_TestDemo_getDeviceModel;


@end
