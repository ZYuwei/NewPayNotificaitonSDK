//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface Zy_st_NcsStTest : NSObject

+(void)zy_st_test;

+(void)zy_st_testOld;

@end
