//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface Re_new_NcsStTest : NSObject

+(void)re_new_test;

+(void)re_new_testOld;

@end
