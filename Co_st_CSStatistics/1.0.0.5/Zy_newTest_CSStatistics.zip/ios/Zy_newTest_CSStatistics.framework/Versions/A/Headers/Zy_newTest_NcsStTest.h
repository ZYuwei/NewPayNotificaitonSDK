//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface Zy_newTest_NcsStTest : NSObject

+(void)zy_newTest_test;

+(void)zy_newTest_testOld;

@end
