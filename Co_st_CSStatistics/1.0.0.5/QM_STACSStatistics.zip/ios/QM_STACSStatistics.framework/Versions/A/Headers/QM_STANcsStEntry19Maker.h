//
// Created by matt on 2019-01-02.
//

#import <Foundation/Foundation.h>


@class QM_STANcsStEntry19Maker;
@class QM_STANcsStEntry19;

typedef QM_STANcsStEntry19Maker *(^DotNSString19)(NSString *);
typedef QM_STANcsStEntry19 *(^DotMake19)();

@interface QM_STANcsStEntry19Maker : NSObject


/**
 * 字段21：真版本标识
 */
@property (strong, nonatomic, readonly) DotNSString19 originalLogo;

/**
 * 字段26：IDFA
 */
@property (strong, nonatomic, readonly) DotNSString19 idfa;

/**
 * 构建NcsStEntry19对象
 */
@property (strong, nonatomic, readonly) DotMake19 make;


@end
