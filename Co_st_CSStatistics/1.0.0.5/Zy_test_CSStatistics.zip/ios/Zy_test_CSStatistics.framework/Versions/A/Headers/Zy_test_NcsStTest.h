//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface Zy_test_NcsStTest : NSObject

+(void)zy_test_test;

+(void)zy_test_testOld;

@end
