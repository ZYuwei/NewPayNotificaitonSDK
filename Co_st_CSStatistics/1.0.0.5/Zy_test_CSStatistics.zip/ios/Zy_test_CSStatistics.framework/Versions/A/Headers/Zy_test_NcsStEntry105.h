//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "Zy_test_NcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface Zy_test_NcsStEntry105 : Zy_test_NcsStEntry103


@end
