//
//  NcsStatisticsApi.h
//  CSStatistics
//
//  Created by matt on 2018/12/7.
//

#import <Foundation/Foundation.h>
#import "Zy_test_NcsStEntryData.h"

@class Zy_test_NcsStInitParams;
@class Zy_test_NcsStInitParamsMaker;
@class Zy_test_NcsStEntryDataMaker;
@class Zy_test_NcsStEntry103Maker;
@class Zy_test_NcsStEntry19Maker;
@class Zy_test_NcsStEntry45Maker;
@class Zy_test_NcsStEntry59Maker;
@class Zy_test_NcsStEntry101Maker;
@class Zy_test_NcsStEntry102Maker;
@class Zy_test_NcsStEntry104Maker;
@class Zy_test_NcsStEntry105Maker;

NS_ASSUME_NONNULL_BEGIN

@interface Zy_test_NcsStatisticsApi : NSObject

/*********************************SDK初始化及配置*****************************************/

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param params 初始化参数，appId必填，其它选填。
 */
+ (void)zy_test_setup:(Zy_test_NcsStInitParams *)params;

/**
 * 启动sdk, 在UIApplicationDelegate#didFinishLaunchingWithOptions里调用。
 * 可重复调用，新配置会覆盖旧配置。没配置的参数，会使用默认配置，而不是上一次的配置。
 * 推荐debug包，默认打开log配置，方便排查问题。
 * @param block 初始化参数，appId必填，其它选填。
 */
+ (void)zy_test_setupByBlock:(void(^)(Zy_test_NcsStInitParamsMaker *maker)) block;

/**
 * 获取当前sdk的配置参数。
 * 如果sdk setup后，想只改变某个配置如log开关，可以先获取当前配置，修改后再setup。
 * @return
 */
+ (Zy_test_NcsStInitParams *)zy_test_getCurrentParams;

/**
 * 程序热启动，回调这个接口。主要是上传19和失败重传。
 */
+ (void)applicationDidBecomeActive;

/*********************************SDK提供的信息*****************************************/

/**
 获取当前SDK版本名称
 */
+ (NSString *)sdkVersionName;

/*********************************统计上传*****************************************/

/**
 * 上传统计，内置支持19、45、59、101～105、自定义协议等。
 * 内置协议使用形如NcsStEntry45、NcsStEntry45Maker，自定义协议使用NcsStEntryData
 * @param entry
 */
+ (void)zy_test_upload:(Zy_test_NcsStEntryData *)entry;

/**
 * 上传自定义统计的简单接口
 * @param data
 */
+ (void)zy_test_uploadSimply:(NSString *)data ;

/**
 * 上传自定义统计
 * @param block
 */
+ (void)zy_test_uploadCustom:(void(^)(Zy_test_NcsStEntryDataMaker *maker)) block;

/**
 * 上传19协议，默认情况下sdk已自动上传，无需客户端调用此接口
 * @param block
 */
+ (void)zy_test_upload19:(void(^)(Zy_test_NcsStEntry19Maker *maker)) block;

/**
 * 上传45协议
 * @param block
 */
+ (void)zy_test_upload45:(void(^)(Zy_test_NcsStEntry45Maker *maker)) block;

/**
 * 上传59协议
 * @param block
 */
+ (void)zy_test_upload59:(void(^)(Zy_test_NcsStEntry59Maker *maker)) block;

/**
 * 上传101协议
 * @param block
 */
+ (void)zy_test_upload101:(void(^)(Zy_test_NcsStEntry101Maker *maker)) block;

/**
 * 上传102协议
 * @param block
 */
+ (void)zy_test_upload102:(void(^)(Zy_test_NcsStEntry102Maker *maker)) block;

/**
 * 上传103协议
 * @param block
 */
+ (void)zy_test_upload103:(void(^)(Zy_test_NcsStEntry103Maker *maker)) block;

/**
 * 上传104协议
 * @param block
 */
+ (void)zy_test_upload104:(void(^)(Zy_test_NcsStEntry104Maker *maker)) block;

/**
 * 上传105协议
 * @param block
 */
+ (void)zy_test_upload105:(void(^)(Zy_test_NcsStEntry105Maker *maker)) block;


@end

NS_ASSUME_NONNULL_END
