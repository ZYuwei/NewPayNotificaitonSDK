//
// Created by matt on 2018-12-27.
//

#import <Foundation/Foundation.h>
#import "masterNcsStEntry103.h"

/**
 * 105协议：http://wiki.3g.net.cn/pages/viewpage.action?pageId=14254166
 */
@interface masterNcsStEntry105 : masterNcsStEntry103


@end
