//
// Created by matt on 2018-12-25.
//

#import <Foundation/Foundation.h>


@interface Test_st_NcsStTest : NSObject

+(void)test_st_test;

+(void)test_st_testOld;

@end
