//
// Created by zhangjiemin on 2018/7/4.
//

#import <Foundation/Foundation.h>

#define GM_PURPOSE_PURCHASE @"PRODUCT_PURCHASE"
#define GM_PURPOSE_RECHARGE @"VCOIN_RECHARGE"
#define GM_PURPOSE_SUBCRIPTION @"PRODUCT_SUBSCRIPTION"

@interface Ne_pay333_PaymentConfig : NSObject
@property (nonatomic,copy) NSString *accessToken;
@property (nonatomic,copy) NSString *accountId;
@property(nonatomic, assign) BOOL isTest;//是否是测试环境 YES代表debug环境
@property(nonatomic, copy) NSString *localPassword;
@property(nonatomic, copy) NSString *staticUUID;

- (void)ne_pay333_initPaymentConfigDebugWithClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey withAppid:(NSString *)AppId ReceiptLocallyWithPassword:(NSString *)password;

- (void)ne_pay333_initPaymentConfigReleaseWithClientID:(NSString *)clientID withSignatureKey:(NSString *)signatureKey withDesKey:(NSString *)desKey withAppid:(NSString *)AppId ReceiptLocallyWithPassword:(NSString *)password;

- (NSString *)ne_pay333_getPayStateDomain;

- (NSString *)ne_pay333_getSignatureKey;

- (NSString *)ne_pay333_getClientID;

- (NSString *)ne_pay333_getStaticUUID;

- (void)setStaticUUID:(NSString *)uuid;

+ (instancetype)ne_pay333_sharedManger;
@end
