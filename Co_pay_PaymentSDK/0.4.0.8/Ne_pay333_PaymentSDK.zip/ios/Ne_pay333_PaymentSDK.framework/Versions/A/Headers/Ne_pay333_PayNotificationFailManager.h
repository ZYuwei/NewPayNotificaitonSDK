//
//  Ne_pay333_PayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "Ne_pay333_PayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface Ne_pay333_PayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)ne_pay333_saveToCacheWithProductId:(NSString *)product_id;
+(Ne_pay333_PayNotificationModel*)ne_pay333_unSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)ne_pay333_delSerializedBean:(Ne_pay333_PayNotificationModel*)bean;
+(NSArray <Ne_pay333_PayNotificationModel *>*)ne_pay333_getSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)ne_pay333_retryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
