//
//  Ne_pay333_PayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Ne_pay333_PayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "Ne_pay333_PayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^Ne_pay333_PayNotificationStateApiCompleteBlock) (Ne_pay333_PayNotificationHTTPResponse *response);

@interface Ne_pay333_PayNotificationStateApiManager : AFHTTPSessionManager
+ (Ne_pay333_PayNotificationStateApiManager *)ne_pay333_sharedManager;
//支付成功新增后台 通知接口
-(void)ne_pay333_checkiOSIAPPayOrderWithPayNotificationModel:(Ne_pay333_PayNotificationModel *)payNotificationModel  complete:(Ne_pay333_PayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
