//
//  Ne_pay_PayDeviceModel.h
//  FMDB
//
//  Created by qiaoming on 2018/12/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Ne_pay_PayDeviceModel : NSObject
+ (NSDictionary *)ne_pay_device;
@end

NS_ASSUME_NONNULL_END
