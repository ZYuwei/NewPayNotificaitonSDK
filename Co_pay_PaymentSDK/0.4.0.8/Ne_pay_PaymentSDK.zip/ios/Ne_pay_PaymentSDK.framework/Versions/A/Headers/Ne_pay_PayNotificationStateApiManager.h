//
//  Ne_pay_PayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Ne_pay_PayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "Ne_pay_PayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^Ne_pay_PayNotificationStateApiCompleteBlock) (Ne_pay_PayNotificationHTTPResponse *response);

@interface Ne_pay_PayNotificationStateApiManager : AFHTTPSessionManager
+ (Ne_pay_PayNotificationStateApiManager *)ne_pay_sharedManager;
//支付成功新增后台 通知接口
-(void)ne_pay_checkiOSIAPPayOrderWithPayNotificationModel:(Ne_pay_PayNotificationModel *)payNotificationModel  complete:(Ne_pay_PayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
