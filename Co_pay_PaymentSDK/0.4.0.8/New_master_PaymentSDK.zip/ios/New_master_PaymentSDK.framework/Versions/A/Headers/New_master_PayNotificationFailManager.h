//
//  New_master_PayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "New_master_PayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface New_master_PayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)new_master_saveToCacheWithProductId:(NSString *)product_id;
+(New_master_PayNotificationModel*)new_master_unSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)new_master_delSerializedBean:(New_master_PayNotificationModel*)bean;
+(NSArray <New_master_PayNotificationModel *>*)new_master_getSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)new_master_retryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
