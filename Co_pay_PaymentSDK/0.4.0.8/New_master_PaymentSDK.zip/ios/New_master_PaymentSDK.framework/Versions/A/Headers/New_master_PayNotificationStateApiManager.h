//
//  New_master_PayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "New_master_PayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "New_master_PayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^New_master_PayNotificationStateApiCompleteBlock) (New_master_PayNotificationHTTPResponse *response);

@interface New_master_PayNotificationStateApiManager : AFHTTPSessionManager
+ (New_master_PayNotificationStateApiManager *)new_master_sharedManager;
//支付成功新增后台 通知接口
-(void)new_master_checkiOSIAPPayOrderWithPayNotificationModel:(New_master_PayNotificationModel *)payNotificationModel  complete:(New_master_PayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
