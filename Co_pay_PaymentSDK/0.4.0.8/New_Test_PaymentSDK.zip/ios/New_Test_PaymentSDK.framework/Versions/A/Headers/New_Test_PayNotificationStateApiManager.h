//
//  New_Test_PayNotificationStateApiManager.h
//  PayNotificationSDK
//
//  Created by qiaoming on 2019/1/22.
//  Copyright © 2019年 qiaoming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "New_Test_PayNotificationModel.h"
#import <AFNetworking/AFNetworking.h>
#import "New_Test_PayNotificationHTTPResponse.h"

NS_ASSUME_NONNULL_BEGIN

//typedef void (^GMPayStateApiCompleteBlock) (GMNetHTTPResponse *response);
typedef void (^New_Test_PayNotificationStateApiCompleteBlock) (New_Test_PayNotificationHTTPResponse *response);

@interface New_Test_PayNotificationStateApiManager : AFHTTPSessionManager
+ (New_Test_PayNotificationStateApiManager *)new_Test_sharedManager;
//支付成功新增后台 通知接口
-(void)new_Test_checkiOSIAPPayOrderWithPayNotificationModel:(New_Test_PayNotificationModel *)payNotificationModel  complete:(New_Test_PayNotificationStateApiCompleteBlock)complete;
@end

NS_ASSUME_NONNULL_END
