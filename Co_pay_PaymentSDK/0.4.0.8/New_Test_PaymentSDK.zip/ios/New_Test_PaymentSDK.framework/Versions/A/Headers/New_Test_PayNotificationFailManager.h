//
//  New_Test_PayNotificationFailManager.h
//  FMDB
//
//  Created by qiaoming on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import "New_Test_PayNotificationModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface New_Test_PayNotificationFailManager : NSObject

//通知服务器的内容先缓存到本地 再上传
+(void)new_Test_saveToCacheWithProductId:(NSString *)product_id;
+(New_Test_PayNotificationModel*)new_Test_unSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
+(void)new_Test_delSerializedBean:(New_Test_PayNotificationModel*)bean;
+(NSArray <New_Test_PayNotificationModel *>*)new_Test_getSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)new_Test_retryUploadPaynotificationRecordFormLocal;
@end

NS_ASSUME_NONNULL_END
