//
//  New_Test_PayDeviceModel.h
//  FMDB
//
//  Created by qiaoming on 2018/12/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface New_Test_PayDeviceModel : NSObject
+ (NSDictionary *)new_Test_device;
@end

NS_ASSUME_NONNULL_END
